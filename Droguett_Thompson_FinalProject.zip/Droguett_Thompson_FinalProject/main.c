//Cristobal Droguett
//Andrew Thompson 
//Sophomore Design Final Project Code

#include <stdint.h>
#include <stdio.h> 
#include <util/delay.h>
#include <avr/io.h>
#include "lcd_driver.h"
#include "port_macros.h"
//Definitons of each motor segment 
//Each each motor section is defined by the number regarding its Pin Number in the schematic
#define MO1 6 // MO1 controls the left motor moving forward
#define MO2 5// MO2 controls the left motor moving reverse
#define MO3 3 // MO3 controls the right motor moving forward
#define MO4 3 // MO4 controls the right motor moving reverse
//Definitions for Buttons
#define A 1 //Each button is defined by the number regarding its Pin Number in the schematic 
#define B 4 
#define C 5 
//Definitions for Directions
#define FORWARD 1 //These definitions are later used for reading which input was chosen
#define REVERSE 2
#define CW 3
#define CCW 4
//PWM Definitions
#define PWM_TOP 100 //Max PWM values
#define PWM_TOP2 100
#define INCREMENT 25 // this is the value we will increment by later when using PWM
//Function Definitions
void forwards(int pwm_speed,float t); //Turn on certain parts of Motors to achieve certain Direction
void reverse(int pwm_speed,float t);
void clockwise(int pwm_speed,float t);
void counterclockwise(int pwm_speed,float t); 
void brake(); //Sets all motors to 0
void float_to_string(float t); //For displaying time as a float
void set_Motors(int directions,int speeds,float t); //Sets the motors with input direction and speed
void run_commands(int direction, int speed, float t); //Function that runs motors when all commands are input
int input_Direction(int press_Counter); //Function which when called displays and saves input of direction user wants
int pwm_Speed(int press_Counter); //Function called which uses PWM to find the speed of the motors the user wants
float input_Time(int press_Counter); //Function called to display and find input time
void display_Command(int command_count); //Function that is called each time a command begins to display command #

// Main Function
int main(){
	//Declarations
	DDRB &=~ ((1<<A) | (1<<B) | (1<<C));
	PORTB |= ((1<<A) | (1<<B) | (1<<C));

	DDRD |= ((1<<MO1)|(1<<MO2)|(MO4));
	PORTD &=~ ((1<<MO1)|(1<<MO2)|(MO4));
	DDRB |= (1<<MO3);
	PORTB &=~ (1<<MO3);

	//Lets us use the LCD driver
	initialize_LCD_driver();
	LCD_execute_command(TURN_ON_DISPLAY);

	//Initialization of Variables
	int press_Counter = 0;
	int direction1, direction2, direction3, direction4 = 0;
	int speed1,speed2,speed3,speed4 = 0;
	float time1,time2,time3,time4 = 0.0;
	int command_count = 1;
	//We use press_Counter to pass through all of the commands, Incrementing it after each command
	//For each value of B I run the corrsponding instruction function to figure out the input
	//Display Command 1 B = 0
	while (press_Counter == 0){
		display_Command(command_count); //Displays Command 1 and waits for the user to press B again
		press_Counter ++;
	}
	command_count ++; //Increments so next command message will show next command
	//Direction 1 Section.  B = 1
	while (press_Counter == 1){
		direction1 = input_Direction(press_Counter); //Saves inputted direction in variable
		press_Counter ++;
	}
	//Speed 1 Section. B = 2 
	while(press_Counter == 2){
		speed1 = pwm_Speed(press_Counter); //Saves inputted speed in variable
		press_Counter ++;
	}
	//Time 1 Section. B = 3
	while (press_Counter == 3){
		time1 = input_Time(press_Counter); //Saves inputted time in variable
		press_Counter ++;
	}
	//Display Command 2 B = 4
	while (press_Counter == 4){
		display_Command(command_count);
		press_Counter ++;
	}
	command_count ++; //Increments so next command message will show next command
	//Direction 2 Message B = 5
	while (press_Counter == 5){
		direction2 = input_Direction(press_Counter);
		press_Counter ++;
	}
	//Speed 2  Message B = 6
	while(press_Counter == 6){
		speed2 = pwm_Speed(press_Counter);
		press_Counter ++;
	}
	//Time 2 Message B = 7
	while (press_Counter == 7){
		time2 = input_Time(press_Counter);
		press_Counter ++;
	}
	//Display Command 3 B = 8
	while (press_Counter == 8){
		display_Command(command_count);
		press_Counter ++;
	}
	command_count ++;
	//Direction 3 Message B = 9
	while (press_Counter == 9){
		direction3 = input_Direction(press_Counter);
		press_Counter ++;
	}
	//Speed 3 Message B = 10
	while(press_Counter == 10){
		speed3 = pwm_Speed(press_Counter);
		press_Counter ++;
	}
	//Time 3 Message B = 11
	while (press_Counter == 11){
		time3 = input_Time(press_Counter);
		press_Counter ++;
	}
	//Display Command 4 B = 12
	while (press_Counter == 12){
		display_Command(command_count);
		press_Counter ++;
	}
	//Direction 4 Message B = 13
	while (press_Counter == 13){
		direction4 = input_Direction(press_Counter);
		press_Counter ++;
	}
	//Speed 4 Message B = 14
	while(press_Counter == 14){
		speed4 = pwm_Speed(press_Counter);
		press_Counter ++;
	}
	//Time 4 Message B = 15
	while (press_Counter == 15){
		time4 = input_Time(press_Counter);
		press_Counter ++;
	}
	//Once all the commands are input, the screen shows "RUN" and runs all the commands shorty after 
	LCD_execute_command(CLEAR_DISPLAY);
	LCD_print_String("  RUN");
	//Running the commands in the main function
	_delay_ms(2000); //Delays 2 secinds before running the commands 
	run_commands(direction1,speed1,time1); // Feeds each commands inputs into a function that will run the motors with those inputs
	run_commands(direction2,speed2,time2);
	run_commands(direction3,speed3,time3);
	run_commands(direction4,speed4,time4);
	return 0;
}

//Functions

// Direction Determining Function
//This is the first of the input functions. When this is called, we find out what direction the user selected based on how many times they pressed C
int input_Direction(int press_Counter){
	int direction_Counter = 0; //This is the integer we return at the end that holds the value of the direction. This is where the definitons of the directions 
	//Above help out. If its 1 we know its forward, 2 is reverse and so on
	int c_Counter = 1; //We have a counter for the C button that is initialized at 1
	while(1){ //We run this while loop until the B button is pressed 
			if( (PINB&(1<<C) )==0 ){ //If C is pressed at any point, the counter is increased and then it runs through the if statements
				_delay_ms(100); //There is a slight delay here to minimize the chance of a long press of C incrementing the variable more than once 
				c_Counter ++; //After C is pressed we add to it to keep track of the amount of presses 
			}
			//Displays current Direction and saves direction in return variable
			if(c_Counter == FORWARD){ //If C has been pressed once then we display forward on the screen and save forward into our return variable
				LCD_execute_command(CLEAR_DISPLAY);
				LCD_print_String("Dir:");
				LCD_move_cursor_to_col_row(0,1);
				LCD_print_String("FORWARD");
				_delay_ms(100);
				direction_Counter = FORWARD;
			}
			if(c_Counter == REVERSE)// If C has been pressed twice we display reverse on the screen and save reverse into the return variable
			{
				LCD_execute_command(CLEAR_DISPLAY);
				LCD_print_String("Dir:");
				LCD_move_cursor_to_col_row(0,1);
				LCD_print_String("REVERSE");
				_delay_ms(100);
				direction_Counter = REVERSE;
			}
			if(c_Counter == CW)// If C has been pressed three times we display CW on the screen and save CW into the return variable
			{
				LCD_execute_command(CLEAR_DISPLAY);
				LCD_print_String("Dir:");
				LCD_move_cursor_to_col_row(0,1);
				LCD_print_String("   CW");
				_delay_ms(100);
				direction_Counter = CW;
			}
			if(c_Counter == CCW)// If C has been pressed 4 times we display CCW on the screen and save CCW into the return variable
			{
				LCD_execute_command(CLEAR_DISPLAY);
				LCD_print_String("Dir:");
				LCD_move_cursor_to_col_row(0,1);
				LCD_print_String("   CCW");
				_delay_ms(100);
				direction_Counter = CCW;
			}
			if(c_Counter > CCW) //If C has been pressed more than 4 times, that means the user means to cycle back through the directions so we 
			//Display Forward, set the counter bacck to 1, and save forward into the return variable
			{
				LCD_execute_command(CLEAR_DISPLAY);
				LCD_print_String("Dir:");
				LCD_move_cursor_to_col_row(0,1);
				LCD_print_String("FORWARD");
				_delay_ms(100);
				c_Counter = FORWARD; //Cycles back through if continually press
				direction_Counter = FORWARD;
			}
			if( (PINB&(1<<B) )==0 ){ //If B is pressed it breaks and returns whatever direction was last saved in the return variable 
				_delay_ms(100);
				break;
			}
	}
	return direction_Counter; //We successfully return the selected direction 
}
// Speed Determining Function
// This uses PWM to figure out the speed the user wants 
int pwm_Speed(int press_Counter){
	//Most of the PWM set up is similar to Lab 7
	unsigned int pwm_counter=0;
	unsigned int duty_cycle=50; // The duty cycle is set to 50 at the start 
	unsigned int last_left_button_state = (PINB & (1<<A)); 
	unsigned int left_button_pressed = 0;
	unsigned int last_right_button_state = (PINB & (1<<C));
	unsigned int right_button_pressed = 0;
	int speed = 0; //This is the return variable we will save the speed in 
	//Configure left push-button
	DDRB &= ~(1<<A); //configure pin as input
	PORTB |= (1<<A); //enable pull-up resistor
	//Configure right push-button
	DDRB &= ~(1<<C); //configure pin as input
	PORTB |= (1<<C);
	while(1)
	{
		//PWM Counter
		pwm_counter = pwm_counter + 1;
		if( pwm_counter >= PWM_TOP ){
			pwm_counter = 0;
		}
		//Pulser for left button
		if( (PINB & (1<<A)) != last_left_button_state ){
			if( (PINB & (1<<A)) == 0 ){
				left_button_pressed=1;
			}
			last_left_button_state = (PINB & (1<<A));
		}
		else{
			left_button_pressed=0;
		}
		//Pulser for right button
		if( (PINB & (1<<C)) != last_right_button_state ){
			if( (PINB & (1<<C)) == 0 ){
				right_button_pressed=1;
			}
			last_right_button_state = (PINB & (1<<C));
		}
		else{
			right_button_pressed=0;
		}
		//Decrement duty cycle when left button pressed
		if( left_button_pressed == 1 ){ //Duty cycle will go from 50 to 25 if A is pressed initially
			if(duty_cycle >= INCREMENT ){
				duty_cycle = duty_cycle - INCREMENT;
			}
			else{
				duty_cycle = 0;
			}
		}
		//Increment duty cycle when right button pressed
		if( right_button_pressed == 1 ){ //Duty cycle will go from 50 to 75 if C is pressed initiallly
			if( duty_cycle <= PWM_TOP -INCREMENT){
				duty_cycle = duty_cycle + INCREMENT;
			}
			else{
				duty_cycle = PWM_TOP;
			}
		}
		//Depending on what the duty_cycle was last, it displays it 
		// It also saves what duty cycle is after any presses into our return variable
		if(duty_cycle == 50){
			LCD_execute_command(CLEAR_DISPLAY);
			LCD_print_String("Speed:");
			LCD_move_cursor_to_col_row(0,1);
			LCD_print_String(" Medium");
			_delay_ms(200);
			speed = 50; //50 is our setting for medium
		}
		if(duty_cycle == 25){
			LCD_execute_command(CLEAR_DISPLAY);
			LCD_print_String("Speed:");
			LCD_move_cursor_to_col_row(0,1);
			LCD_print_String("  Slow");
			_delay_ms(200);
			speed = 30;//30 is our setting for slow
		}
		if(duty_cycle == 75){
			LCD_execute_command(CLEAR_DISPLAY);
			LCD_print_String("Speed:");
			LCD_move_cursor_to_col_row(0,1);
			LCD_print_String("  Fast");
			_delay_ms(200);
			speed = 70; //70 is our setting for fast
		}
		if( (PINB&(1<<B) )==0 ){ //If B is ever pressed it returns that last saved speed, which is the selected speed
			_delay_ms(100);
			break;
		}
		//When B is pressed it breaks the loop and returns the value of the speed chosen
	}
	return speed;
}
// Time Determining Function
// This Function decreases and increases time based on button clicks
float input_Time(int press_Counter)
{	
	float t = 1.0; //the beginning time is 1.0 seconds by default
	float time_disp = 0.0; //This variable is the variable we will store our final time into and return at the end
	while(1){
		LCD_execute_command(CLEAR_DISPLAY);
		float_to_string(t); //In our float to string function we display the current time 
		if( ( PINB&(1<<A) )==0 ){ //When A pressed, decreases by .1
			_delay_ms(100);
			t = t -.1;
			if(t < .1)
			{
				t = 0.0; //Makes sure it can never be negative
			}
		}
		if( (PINB&(1<<C) )==0) { //When C pressed, increases by .1
			_delay_ms(100);
			t = t + .1;
			if(t > 6.0){ //The max time will be kept internally at 6 seconds
				t = 6.0; 
			}
		}			
		if( (PINB&(1<<B) )==0 ){ //If B is pressed it ends the loop and return the selected time
			_delay_ms(100);
			break;
		}
	}
	time_disp = t ; //Saves that selected time into our return variable
	t = 1.0; //returns time back to default of 1.0 seconds
	return time_disp;
}
//Function for displaying command number between inputs
void display_Command(int command_count)
{
	while(1){
		//Based on what stage the main is at, it displays the corresponding command #
		if(command_count == 1){
			LCD_execute_command(CLEAR_DISPLAY);
			LCD_print_String("Command");
			LCD_move_cursor_to_col_row(0,1);
			LCD_print_String("   1");
			_delay_ms(100);
		}
		if(command_count == 2){
			LCD_execute_command(CLEAR_DISPLAY);
			LCD_print_String("Command");
			LCD_move_cursor_to_col_row(0,1);
			LCD_print_String("   2");
			_delay_ms(100);
		}
		if(command_count == 3){
			LCD_execute_command(CLEAR_DISPLAY);
			LCD_print_String("Command");
			LCD_move_cursor_to_col_row(0,1);
			LCD_print_String("   3");
			_delay_ms(100);
		}
		if(command_count == 4){
			LCD_execute_command(CLEAR_DISPLAY);
			LCD_print_String("Command");
			LCD_move_cursor_to_col_row(0,1);
			LCD_print_String("   4");
			_delay_ms(100);
		}
		if( (PINB&(1<<B) )==0 ){
				_delay_ms(100);
				break;
		}
	}
}
void float_to_string(float t) 
{ 
	char str[] = "1.0"; //Saves the default time into our string
	int whole_Number = t; // Give me whole number
	float difference = t - whole_Number; //Give me decimal part of input
	int decimal = trunc(difference * 10); //makes that decimal a whole number
	str[0] = whole_Number + '0'; //We edit the whole number and decimal section of our string to match out inputted time 
	str[2] = decimal + '0';
	LCD_print_String("Time:");
	LCD_move_cursor_to_col_row(0,1);
	LCD_print_String(str); //We then display that selected float time as a string 
	_delay_ms(100);
}

// Running Commands Function
//This functio takes the inputs of the command and runs them though a function that decides which directions function to run it through
// It also adds a delay after so the commands do not go into each other to make the run more smooth
void run_commands(int direction, int speed, float t)
{
	set_Motors(direction,speed,t);// insert variables for command
	_delay_ms(500);
}

// This function reads the input direction and then sends the speed and time of the command to the respective function that will set the motors in that direction
void set_Motors(int directions,int speeds,float t)
// Chooses the appropriate direction function based on direction value
// It also calls the brake function after the direction functions so that the motors will stop moving after the function ends
{
	if(directions == FORWARD)
	{
		forwards(speeds,t);
		brake(speeds);
	}
	else if(directions == REVERSE)
	{
		reverse(speeds,t);
		brake(speeds);
	}
	else if(directions == CW)
	{
		clockwise(speeds,t);
		brake(speeds);
	}
	else if(directions == CCW)
	{
		counterclockwise(speeds,t);
		brake(speeds);
	}
}
//These directional functions are the ones that set the motors with the users inputs
// We accept the speed of the motor as duty_cycle and the time it will run as t
// We use PWM again here to run the commands
// For the speed, we use a system of turning motors on and off to add a certain amount of resistance to the direction
// The more often we toggle the motors that should be off for a certain direction, the less the motor runs at its max Speed
// We have a counter that counts how long the while loop is running and we made it where the motors toggle on when the current time is disibile by certain values
// For example for our slow setting we divide of the current time in the loop in ms by 2 and if the remainder is 0 then we make the motors all 0
// Since this is basically just reading every 1ms if its even or odd and stopping the motor half of the time, this makes the motors run at 50% which is our slow value
// The other speeds work on a similar idea but the amount the time is divided by is different 
// For medium it is divided by 4, so the motor runs at 75% of its speed when medium is selected 
// And for fast it is divided by 10 so the motor runs at 90% of its speed
void forwards(int duty_cycle, float t){
	int pwm_counter = 0;
	int remainder = 0; // This will calculate the remainder of the division of the time and percent number
	int even_odd = 3; // The ms counter starts at 3
	int percent = 0; //We use this to save 2,4, or 10 as the divisor depending on the inputted speed
	uint16_t us_counter = 0; //This will be used to keep track of how many microseconds have passed
	uint16_t ms_counter = 0; //This will be used to keep track of how many milliseconds have passed
	uint16_t breakt = t * 1000; // This takes our time and converts it to milliseconds 
	if(duty_cycle == 30){ //If the speed is slow, then we make our divisor 2 so it goes at 50%
		percent = 2;
	}
	if(duty_cycle == 50){//If the speed is medium we make our divisor 4 so it goes at 75%
		percent = 4;
	}
	if(duty_cycle == 70){//If the speed is fast we make our divisor 10 so it goes at 90%
		percent = 10;
	}
	while(1){ //Then we start our while loop that will run untill the input time is reached
		remainder = even_odd % percent; //We find the remainder based on the percent above
		_delay_us(10); //We then delay the loop for 10 microseconds
		us_counter += 10; //And so we add 10 to our microseconds counter to keep a track of time
		if(us_counter >= 1000){ //The counter reached 1000 that means 1 ms has passed so we add 1 to ms and set us back to 0
			us_counter = 0;
			ms_counter ++;
		}
		if(ms_counter >= breakt){//If the millisecond counter reaches the time input then we end the function
			us_counter = 0;
			ms_counter = 0;
			break;
		}
		pwm_counter ++;
		if(pwm_counter >= PWM_TOP2){
			pwm_counter = 0;
		}
		if(pwm_counter< duty_cycle){ //This statement runs every 10us. Depending on the remainder value, the motors will be set to two different things
			if(remainder != 0){ //If the remainder is not 0 then the motors are set in the normal setup for moving forward
				PORTD &= ~(1 << MO2);    // drive pin PD5 low
				PORTD |= (1 << MO1);
				PORTD &= ~(1 << MO4);    // drive pin PD3 low
				PORTB |= (1 << MO3);
			}
			if(remainder == 0){ //However if the remainder is 0 then for that 10us the motors will all be set to 0, making it slower 
				PORTD &= ~(1 << MO2);    // drive pin PD5 low
				PORTD &= ~(1 << MO1);
				PORTD &= ~(1 << MO4);    // drive pin PD3 low
				PORTB &= ~(1 << MO3);
			}
		}
		else
		{
			PORTD &= ~((1<<MO1)|(1<<MO2)|(1<<MO4));
			PORTB &= ~(1<<MO3);
		}
		even_odd ++; //At the end of the 10us. We add one to the ms counter to calculate a new remainder
	}
}
// The following direction functions work in the same way except the set up of the motors are all different depending on their direction
void reverse(int duty_cycle, float t){
	int pwm_counter = 0;
	int remainder = 0;
	int even_odd = 3;
	int percent = 0;
	uint16_t us_counter = 0;
	uint16_t ms_counter = 0;
	uint16_t breakt = t * 1000; 
	if(duty_cycle == 30){
		percent = 2;
	}
	if(duty_cycle == 50){
		percent = 4;
	}
	if(duty_cycle == 70){
		percent = 10;
	}
	while(1){
		remainder = even_odd % percent;
		_delay_us(10);
		us_counter += 10;
		if(us_counter >= 1000){
			us_counter = 0;
			ms_counter ++;
		}
		if(ms_counter >= breakt){
			us_counter = 0;
			ms_counter = 0;
			break;
		}
		pwm_counter ++;
		if(pwm_counter >= PWM_TOP2){
			pwm_counter = 0;
		}
		if(pwm_counter< duty_cycle){
			if(remainder != 0){
				PORTD |= (1 << MO2);    // drive pin PD5 high
				PORTD &= ~(1 << MO1);
				PORTD |= (1 << MO4);    // drive pin PD3 high
				PORTB &= ~(1 << MO3);
			}
			if(remainder == 0){
				PORTD &= ~(1 << MO2);    // drive pin PD5 low
				PORTD &= ~(1 << MO1);
				PORTD &= ~(1 << MO4);    // drive pin PD3 low
				PORTB &= ~(1 << MO3);
			}
		}
		else
		{
			PORTD &= ~((1<<MO1)|(1<<MO2)|(1<<MO4));
			PORTB &= ~(1<<MO3);
		}
		even_odd ++;
	}
}
void clockwise(int duty_cycle, float t){
	int pwm_counter = 0;
	int remainder = 0;
	int even_odd = 3;
	int percent = 0;
	uint16_t us_counter = 0;
	uint16_t ms_counter = 0;
	uint16_t breakt = t * 1000; 
	if(duty_cycle == 30){
		percent = 2;
	}
	if(duty_cycle == 50){
		percent = 4;
	}
	if(duty_cycle == 70){
		percent = 10;
	}
	while(1){
		remainder = even_odd % percent;
		_delay_us(10);
		us_counter += 10;
		if(us_counter >= 1000){
			us_counter = 0;
			ms_counter ++;
		}
		if(ms_counter >= breakt){
			us_counter = 0;
			ms_counter = 0;
			break;
		}
		pwm_counter ++;
		if(pwm_counter >= PWM_TOP2){
			pwm_counter = 0;
		}
		if(pwm_counter< duty_cycle){
			if(remainder != 0){
				PORTD &= ~(1 << MO2);    // drive pin PD5 low
				PORTD |= (1 << MO1);
				PORTD |= (1 << MO4);    // drive pin PD3 high
				PORTB &= ~(1 << MO3);
			}
			if(remainder == 0){
				PORTD &= ~(1 << MO2);    // drive pin PD5 low
				PORTD &= ~(1 << MO1);
				PORTD &= ~(1 << MO4);    // drive pin PD3 low
				PORTB &= ~(1 << MO3);
			}
		}
		else
		{
			PORTD &= ~((1<<MO1)|(1<<MO2)|(1<<MO4));
			PORTB &= ~(1<<MO3);
		}
		even_odd ++;
	}
}

void counterclockwise(int duty_cycle, float t){
	int pwm_counter = 0;
	int remainder = 0;
	int even_odd = 3;
	int percent = 0;
	uint16_t us_counter = 0;
	uint16_t ms_counter = 0;
	uint16_t breakt = t * 1000; 
	if(duty_cycle == 30){
		percent = 2;
	}
	if(duty_cycle == 50){
		percent = 3;
	}
	if(duty_cycle == 70){
		percent = 10;
	}
	while(1){
		remainder = even_odd % percent;
		_delay_us(10);
		us_counter += 10;
		if(us_counter >= 1000){
			us_counter = 0;
			ms_counter ++;
		}
		if(ms_counter >= breakt){
			us_counter = 0;
			ms_counter = 0;
			break;
		}
		pwm_counter ++;
		if(pwm_counter >= PWM_TOP2){
			pwm_counter = 0;
		}
		if(pwm_counter< duty_cycle){
			if(remainder != 0){
				PORTD |= (1 << MO2);    // drive pin PD5 high
				PORTD &= ~(1 << MO1); 
				PORTD &= ~(1 << MO4);    // drive pin PD3 low
				PORTB |= (1 << MO3);
			}
			if(remainder == 0){
				PORTD &= ~(1 << MO2);    // drive pin PD5 low
				PORTD &= ~(1 << MO1);
				PORTD &= ~(1 << MO4);    // drive pin PD3 low
				PORTB &= ~(1 << MO3);
			}
		}
		else
		{
			PORTD &= ~((1<<MO1)|(1<<MO2)|(1<<MO4));
			PORTB &= ~(1<<MO3);
		}
		even_odd ++;
	}
}
// This brake function also has a time counter except this brake function ends after 1000 ms have passed. I decided to make this just to it gives a 1 second break inbetween
void brake(int duty_cycle){
	int pwm_counter = 0;
	uint16_t us_counter = 0;
	uint16_t ms_counter = 0;
	uint16_t breakt = 1000; // you should t*1000 to get ms format.
	while(1){
		_delay_us(10);
		us_counter += 10;
		if(us_counter >= 1000){
			us_counter = 0;
			ms_counter ++;
		}
		if(ms_counter >= breakt){
			us_counter = 0;
			ms_counter = 0;
			break;
		}
		pwm_counter ++;
		if(pwm_counter >= PWM_TOP2){
			pwm_counter = 0;
		}
		if(pwm_counter< duty_cycle){ //Makes all the motors stop moving 
			PORTD &= ~(1<<MO1);
			PORTB &= ~(1<<MO3);
			PORTD &= ~(1<<MO2);
			PORTD &= ~(1<<MO4);
		}
	}
}
// This is the end of the project




